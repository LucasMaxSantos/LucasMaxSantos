﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482023021
{
    public partial class FrmAvaliacao : Form
    {
        public FrmAvaliacao()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            double[,] N = new double[1, 4]; //RA = 1
            string aux = "";
            int s; // Semana 
            int m; // Mês

            //entradas dos dados
            for (m = 0; m < N.GetLength(0); m++) //Retorna N=1
            {
                for (s = 0; s < N.GetLength(1); s++) //Retorna N=4
                {
                    aux = Interaction.InputBox((s + 1) + "° Semana " +  ": R$", "Mês " + (m + 1)+ ":"); 

                    if (aux == "")
                        break;

                    if (!double.TryParse(aux, out N[m, s]))  
                    {                                      
                        MessageBox.Show("Valor Inválido R$");
                        s--;
                    }
                }
            }
            //saida dos resultados
            double TMes; 
            double TGMeses = 0;

            for (m = 0; m < N.GetLength(0); m++)
            {
                LsbResultado.Items.Add("Total do mês: " + (m + 1) + ("\n"));
                TMes = 0;// para RA > 0 
                for (s = 0; s < N.GetLength(1); s++)
                {
                    LsbResultado.Items.Add((s + 1) + "° Semana: " +  " " +  N[m, s].ToString("C2") + ("\n"));
                                                                                                                                  
                    TMes += N[m, s];  
                }
                LsbResultado.Items.Add("Total do mês: " + TMes.ToString("C2") + ("\n"));
                TGMeses += TMes;
            }
            LsbResultado.Items.Add(("\n"));
            LsbResultado.Items.Add(">>Total Geral: " + TGMeses.ToString("C2") + ("\n")); 
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            LsbResultado.Items.Clear();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
